INSERT INTO catalog 
            (`id`,`type`,`name`,`price`,`currency`,`description`,`parent_id`,`yml_catalog_id`,`active`,`allow_order`,`cover`,`user_id`,`sort`,`created_at`,`updated_at`,`article`,`discount`,`price_filter`,`action`,`action_title`,`action_param`,`params_hash`,`quantity`) 
            VALUES('156046','0','Машинки для стрижки','0','','','0','3','1','0','','9','1','2013-12-12 13:08:02','2014-09-10 13:23:14','3','0','0','','','','','0');
INSERT INTO catalog 
            (`id`,`type`,`name`,`price`,`currency`,`description`,`parent_id`,`yml_catalog_id`,`active`,`allow_order`,`cover`,`user_id`,`sort`,`created_at`,`updated_at`,`article`,`discount`,`price_filter`,`action`,`action_title`,`action_param`,`params_hash`,`quantity`) 
            VALUES('156047','0','Электрочайники','0','','','0','4','1','0','','9','2','2013-12-12 13:08:02','2014-09-10 13:23:38','4','0','0','','','','','0');
INSERT INTO catalog 
            (`id`,`type`,`name`,`price`,`currency`,`description`,`parent_id`,`yml_catalog_id`,`active`,`allow_order`,`cover`,`user_id`,`sort`,`created_at`,`updated_at`,`article`,`discount`,`price_filter`,`action`,`action_title`,`action_param`,`params_hash`,`quantity`) 
            VALUES('156054','1','Машинка для стрижки Panasonic ER508','5400','RUR','Профессиональная машинка для стрижки волос. Насадка для прореживания обеспечит естественный вид прическе, сверхпрочное покрытие лезвий Diamond для длительной и качественной эксплуатации.','156046','41','1','1','323c9b36b58903294fce55de77e83e2f.jpg','9','1','2013-12-12 13:08:02','2014-09-10 13:23:07','i2421400','0','0','','','','','0');
INSERT INTO catalog 
            (`id`,`type`,`name`,`price`,`currency`,`description`,`parent_id`,`yml_catalog_id`,`active`,`allow_order`,`cover`,`user_id`,`sort`,`created_at`,`updated_at`,`article`,`discount`,`price_filter`,`action`,`action_title`,`action_param`,`params_hash`,`quantity`) 
            VALUES('156055','1','Машинка для стрижки Babyliss E 842 для бороды и ..','4000','RUR','Техническая характеристика- Тип: вибрационная- Питание: сеть/аккумулятор- Время автономной работы: 30 мин- Ножи: титан+покрытие CMS- Цвет: синий','156046','42','1','1','a7efdc19068611b5a2e069381cd4a077.jpg','9','2','2013-12-12 13:08:02','2014-09-10 13:23:14','i2421401','0','0','','','','','0');
INSERT INTO catalog 
            (`id`,`type`,`name`,`price`,`currency`,`description`,`parent_id`,`yml_catalog_id`,`active`,`allow_order`,`cover`,`user_id`,`sort`,`created_at`,`updated_at`,`article`,`discount`,`price_filter`,`action`,`action_title`,`action_param`,`params_hash`,`quantity`) 
            VALUES('156056','1','Электрочайник Mirta KTT 123','1900','RUR','Чайник NOVIS NKT-712 нержавейкаОбъемом 1.7л Корпус -нержавеющая сталь, Для удобства пользованием, имеет индикацию нагрева. скрытый нагревательный элемент световая индикация нагрева съемный фильтр мощность 2000 Вт','156047','39','1','1','82a22597b78c9c9d62d64a66f0263d58.jpg','9','1','2013-12-12 13:08:02','2014-09-10 13:23:32','i2421403','0','0','','','','','0');
INSERT INTO catalog 
            (`id`,`type`,`name`,`price`,`currency`,`description`,`parent_id`,`yml_catalog_id`,`active`,`allow_order`,`cover`,`user_id`,`sort`,`created_at`,`updated_at`,`article`,`discount`,`price_filter`,`action`,`action_title`,`action_param`,`params_hash`,`quantity`) 
            VALUES('156057','1','Электрочайник Lumme LU-2051','6000','RUR','ОБЪЕМ 1.8 л, Для удобства пользованием, имеет 2 индикации подсветки. Синяя- нагрев отключен, красную-при нагреве. - скрытый нагревательный элемент - двух цветная индикация работы - съемный фильтр - мощность 2000 Вт','156047','40','1','1','c488e5f8939bd878e25d437878b52060.jpg','9','2','2013-12-12 13:08:02','2014-09-10 13:23:38','i2421404','0','0','','','','','0');
INSERT INTO catalog_photos 
            (`id`,`ext`,`path`,`name`,`dimension`,`white`,`catalog_id`,`user_id`,`sort`,`created_at`,`updated_at`,`yml_url`,`yml_size`,`asset_server`) 
            VALUES('140956','jpg','2013/12/12','6963b5945fa80116e4ecbf54d3bc8547.jpg','78*78','0','156046','9','1','2013-12-12 13:08:02','2013-12-12 13:08:02','','0','2');
INSERT INTO catalog_photos 
            (`id`,`ext`,`path`,`name`,`dimension`,`white`,`catalog_id`,`user_id`,`sort`,`created_at`,`updated_at`,`yml_url`,`yml_size`,`asset_server`) 
            VALUES('140957','jpg','2013/12/12','f7c96060769499acb2d0c2c0e754ca79.jpg','89*89','0','156047','9','1','2013-12-12 13:08:02','2013-12-12 13:08:02','','0','2');
INSERT INTO catalog_photos 
            (`id`,`ext`,`path`,`name`,`dimension`,`white`,`catalog_id`,`user_id`,`sort`,`created_at`,`updated_at`,`yml_url`,`yml_size`,`asset_server`) 
            VALUES('310589','jpg','2013/12/12','323c9b36b58903294fce55de77e83e2f.jpg','78*100','1','156054','9','1','2014-09-10 13:23:07','2014-09-10 13:23:07','','0','2');
INSERT INTO catalog_photos 
            (`id`,`ext`,`path`,`name`,`dimension`,`white`,`catalog_id`,`user_id`,`sort`,`created_at`,`updated_at`,`yml_url`,`yml_size`,`asset_server`) 
            VALUES('310590','jpg','2013/12/12','a7efdc19068611b5a2e069381cd4a077.jpg','36*100','1','156055','9','1','2014-09-10 13:23:14','2014-09-10 13:23:14','','0','2');
INSERT INTO catalog_photos 
            (`id`,`ext`,`path`,`name`,`dimension`,`white`,`catalog_id`,`user_id`,`sort`,`created_at`,`updated_at`,`yml_url`,`yml_size`,`asset_server`) 
            VALUES('310591','jpg','2013/12/12','82a22597b78c9c9d62d64a66f0263d58.jpg','89*100','1','156056','9','1','2014-09-10 13:23:33','2014-09-10 13:23:33','','0','2');
INSERT INTO catalog_photos 
            (`id`,`ext`,`path`,`name`,`dimension`,`white`,`catalog_id`,`user_id`,`sort`,`created_at`,`updated_at`,`yml_url`,`yml_size`,`asset_server`) 
            VALUES('310592','jpg','2013/12/12','c488e5f8939bd878e25d437878b52060.jpg','80*100','1','156057','9','1','2014-09-10 13:23:38','2014-09-10 13:23:38','','0','2');
INSERT INTO search_stats 
            (`id`,`text`,`user_agent`,`created_at`,`lat`,`lng`,`client_id`) 
            VALUES('200680','aer','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:36.0) Gecko/20100101 Firefox/36.0','2015-03-14 13:44:34','55.7519','37.6356','9');
INSERT INTO search_stats 
            (`id`,`text`,`user_agent`,`created_at`,`lat`,`lng`,`client_id`) 
            VALUES('482249','aer','Mozilla/5.0 (Windows NT 6.1; WOW64) SkypeUriPreview Preview/0.5','2015-09-20 07:39:55','55.7519','37.6356','9');
